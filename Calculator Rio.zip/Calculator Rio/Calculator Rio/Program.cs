﻿using System;

class Program
{
    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("\n=== Simple Calculator ===");
            Console.WriteLine("1. Addition");
            Console.WriteLine("2. Subtraction");
            Console.WriteLine("3. Multiplication");
            Console.WriteLine("4. Division");
            Console.WriteLine("5. Exit");

            Console.Write("Choose an option (1-5): ");
            string choice = Console.ReadLine();

            if (choice == "5")
            {
                Console.WriteLine("Goodbye!");
                break;
            }

            if (choice != "1" && choice != "2" && choice != "3" && choice != "4")
            {
                Console.WriteLine("Invalid choice. Please try again.");
                continue;
            }

            try
            {
                Console.Write("Enter the first number: ");
                double num1 = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter the second number: ");
                double num2 = Convert.ToDouble(Console.ReadLine());

                double result = 0;
                string operation = "";

                switch (choice)
                {
                    case "1":
                        result = num1 + num2;
                        operation = "+";
                        break;
                    case "2":
                        result = num1 - num2;
                        operation = "-";
                        break;
                    case "3":
                        result = num1 * num2;
                        operation = "*";
                        break;
                    case "4":
                        if (num2 == 0)
                        {
                            Console.WriteLine("Error: Cannot divide by zero.");
                            continue;
                        }
                        result = num1 / num2;
                        operation = "/";
                        break;
                }

                Console.WriteLine($"\nResult: {num1} {operation} {num2} = {result}");
            }
            catch
            {
                Console.WriteLine("Invalid input. Please enter numeric values.");
                continue;
            }

            Console.Write("\nDo you want to perform another calculation? (yes/no): ");
            string again = Console.ReadLine().ToLower();

            if (again != "yes")
            {
                Console.WriteLine("Goodbye!");
                break;
            }
        }
    }
}